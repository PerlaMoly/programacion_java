package ar.edu.unlam.pb2.Cuenta;

public abstract class Cuenta {
	protected Double saldo;
	 
	public Cuenta (Double saldo)
	{
		this.saldo=saldo;
		
	}
	
	public abstract Boolean extraer(Double saldo);
	public abstract Boolean depositar(Double saldo);	
	
}
