package ar.edu.unlam.pb2.Cuenta;

public class CuentaSueldo extends Cuenta {

	public CuentaSueldo(Double saldo) {
		super(saldo);

	}

	// M�todo extraer
public Boolean extraer (Double monto) {
	Boolean resultado = false;
    if(this.saldo>=monto) {
		this.saldo= this.saldo-monto;
		resultado = true;
    }
	return resultado;
}

public Boolean depositar (Double monto) {
	Boolean resultado = false;

	if(monto>0)
	{
		this.saldo=saldo+monto;
		resultado= true;
	}
	return resultado;
}

}
