package ar.edu.unlam.pb2.CuentaTest;

import static org.junit.Assert.*;

import org.junit.Test;


public class CuentaTest {

	@Test
	public void probarExtraccion() {
		CuentaTest miCuentaTest = new CuentaTest();
		Boolean valorEsperado= true;
		Boolean valorObtenido= miCuentaTest.extraer();
		assertEquals(valorEsperado, valorObtenido);
	}

	@Test
	public void probardepositar() {
		CuentaTest miCuentaTest = new CuentaTest();
		Cuenta.depositar(400);
		Double saldo = Cuenta.getSaldo();
		Boolean valorEsperado= true;
		Boolean valorObtenido= miCuentaTest.depositar(200.00);
		assertEquals(valorEsperado, valorObtenido);
	}
}

